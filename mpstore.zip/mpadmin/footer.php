<?php

echo'<footer class="footer footer-black  footer-white ">
        <div class="container-fluid">
          <div class="row">
            <nav class="footer-nav">
            </nav>
            <div class="credits ml-auto">
              <span class="copyright">
                ©
                <script>
                  document.write(new Date().getFullYear())
                </script> Muslim Preneurship, dibuat oleh 
                <a href="mailto:contact@imwumbo.com?subject=Pemesanan-Projek&body=Isi-Pesan-Anda...">Wumbo Group</a>
              </span>
            </div>
          </div>
        </div>
    </footer>';

?>