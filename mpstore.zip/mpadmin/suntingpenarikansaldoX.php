<?php
require_once("koneksidb.php");

  $id_tarik          = $_POST['id_tarik'];
  $status_tarik      = $_POST['status_tarik'];

  // menyiapkan query
  $sql = "UPDATE tarik_saldo SET status_tarik='$status_tarik' WHERE id_tarik='$id_tarik' ";
  $stmt = $db->prepare($sql);

  // bind parameter ke query
  $params = array(
      ":id_tarik" => $id_tarik,
      ":status_tarik" => $status_tarik
  );

  // eksekusi query untuk menyimpan ke database
  $saved = $stmt->execute($params);

  // jika query simpan berhasil, maka user sudah terdaftar
  // maka alihkan ke halaman login
  if($saved) header("Location: penarikansaldo");

?>