<?php
require 'koneksi.php';
include 'secure.php';
include 'wa_woonotif.php';
include 'mpadmin/generatekatasandi.php';
date_default_timezone_set("Asia/Jakarta");

$ambil = $koneksi->query("SELECT * FROM `order` LEFT JOIN order_detail ON `order`.id_order = order_detail.id_order LEFT JOIN produk ON order_detail.id_produk = produk.id_produk WHERE produk.id_kategori = 1 AND `order`.status_pembayaran ='pending' AND `order`.bool_wa = 1");
while ($pecah = $ambil->fetch_assoc()) {
    $idMem = $pecah['id_member'];
    $id_order = $pecah['id_order'];
    $tgl_bayar = date("Y-m-d");

    $curl = curl_init();
	curl_setopt_array($curl, array(
	  CURLOPT_URL => "https://api.sandbox.midtrans.com/v2/".$id_order."/status",
	  CURLOPT_RETURNTRANSFER => true,
	  CURLOPT_ENCODING => "",
	  CURLOPT_MAXREDIRS => 10,
	  CURLOPT_TIMEOUT => 30,
	  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
	  CURLOPT_CUSTOMREQUEST => "GET",
	  CURLOPT_HTTPHEADER => array(
	    "Authorization: Basic U0ItTWlkLXNlcnZlci1COXJDR0JMSTZobmNXMWhFbGpSMV9DRTE="
	  ),
	));

	$response = curl_exec($curl);
	$err = curl_error($curl);

    curl_close($curl);
    
    $hasil = json_decode($response, true);
    $status_transaksi = $hasil['transaction_status'];
    // Kalau yg beli pakai link referal kirim pesan ke member juga
    if ($idMem != "MB000000001") {
        $ambilNo = $koneksi->query("SELECT * FROM user WHERE id_user = '$idMem'");
        $pecahNo = $ambilNo->fetch_assoc();
        $noHP = $pecahNo['no_hp'];
        $email = $pecahNo['email_user']
        if ($status_transaksi == 'pending') {
            
            //kirim wa ke siswa pending
            $pesan = "untuk siswa pending";
            wa_mp($noHP, $pesan);
        }
        elseif ($status_transaksi == 'settlement') {
            resetPassword($email);
            //kirim wa ke siswa pesan sukses mp
            $pesan = "untuk siswa sukses";
            wa_mp($noHP, $pesan);
        }
        else {
            //kirim wa ke siswa pesan gagal mp
            $pesan = "untuk siswa gagal";
            wa_mp($noHP, $pesan);
        }
        echo $noHP;
        echo "\n";
        echo $pesan;
        echo "\n";
    }
    $noHP = $pecah['nohp_pembeli'];
    // kirim pesan ke pembeli
    if ($status_transaksi == 'pending') {
        //kirim wa ke pembeli pending
        $bool_wa = 1;
        $pesan = "untuk pembeli pending";
        wa_mp($noHP, $pesan);
    }
    elseif ($status_transaksi == 'settlement') {
        resetPassword($email);
        //kirim wa ke pembeli pesan sukses mp
        $bool_wa = 2;
        $pesan = "untuk pembeli sukses";
        wa_mp($noHP, $pesan);
    }
    else {
        //kirim wa ke pembeli pesan gagal mp
        $bool_wa = 2;
        $pesan = "untuk pembeli gagal";
        wa_mp($noHP, $pesan);
    }
    echo $noHP;
    echo "\n";
    echo $pesan;
    echo "\n";

    $koneksi->query("UPDATE `order` SET status_pembayaran = '$status_transaksi', tgl_bayar = '$tgl_bayar', bool_wa = '$bool_wa' WHERE id_order = '$id_order'");

    echo $id_order;
    echo "\n";
    echo $status_transaksi;

    
}

function wame($nohp){
    $nohape = "089507229772";
    $if62 = substr($nohape, 0, 2);

    if ($if62 == "62") {
        $nohape = $nohape;
    }
    else {
        $nohape = "62".substr($nohape,1);
    }
    $wame = "wa.me/".$nohape;
}
?>